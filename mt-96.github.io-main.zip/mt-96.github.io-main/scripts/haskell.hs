#!/usr/bin/env stack
-- stack --resolver=lts-12.7 script

main :: IO ()
main = do
  putStrLn "hello, scripting!"
