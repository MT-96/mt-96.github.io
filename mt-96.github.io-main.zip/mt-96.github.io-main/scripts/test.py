my_string = "CodeShack"
reversed_string = my_string[::-1]
print(reversed_string) # Result: "ckahSedoc"