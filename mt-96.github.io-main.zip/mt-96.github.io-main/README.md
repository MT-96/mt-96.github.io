
A repository that hosts some of my old projects. Experiment at your own risk! ⚠️

Feel free to provide feedback about incompatibility/bugs!

https://mt-96.github.io/repo/
